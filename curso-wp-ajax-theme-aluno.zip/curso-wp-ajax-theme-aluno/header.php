<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Ajax sem segredos</title>
	<?php wp_head(); ?>
</head>
<body>
<main>